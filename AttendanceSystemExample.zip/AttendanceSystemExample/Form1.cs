﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace AttendanceSystemExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void textBoxUsername_TextChanged_2(object sender, EventArgs e)
        {
            textBoxUsername.BackColor = Color.Lavender;
            panelUsername.BackColor = Color.Lavender;
            textBoxPassword.BackColor = SystemColors.Control;
            panelPassword.BackColor = SystemColors.Control;
            labelUsername.BackColor = Color.Lavender;
            labelPassword.BackColor = SystemColors.Control;
        }

        private void textBoxPassword_TextChanged(object sender, EventArgs e)
        {
            textBoxUsername.BackColor = SystemColors.Control;
            panelUsername.BackColor = SystemColors.Control;
            textBoxPassword.BackColor = Color.Lavender;
            panelPassword.BackColor = Color.Lavender;
            labelPassword.BackColor = Color.Lavender;
            labelUsername.BackColor = SystemColors.Control;
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }


        private void buttonLogin_Click(object sender, EventArgs e)
        {

        }

        private void buttonReset_Click(object sender, EventArgs e)
        {

        }

        private void labelUsername_Click(object sender, EventArgs e)
        {

        }


        private void buttonLogin_Click_1(object sender, EventArgs e)
        {
            if (textBoxUsername.Text == "Admin")
            {
                if (textBoxPassword.Text == "Fudge")
                {
                    Form Form4 = new Form4();
                    Form4.ShowDialog();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong Username and Password");
                }
            }
            else
            {
                MessageBox.Show("Wrong Username and Password");
            }
        }


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowPass.Checked == true)
            {
                textBoxPassword.UseSystemPasswordChar = false;
            }
            else
            {
                textBoxPassword.UseSystemPasswordChar = true;
            }
        }

        private void textBoxUsername_TextChanged_3(object sender, EventArgs e)
        {

        }

        private void panelUsername_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelAMS_Click(object sender, EventArgs e)
        {

        }
    }
}
